import dash_core_components as dcc
import dash_bootstrap_components as dbc
import dash_html_components as html
from dash.dependencies import Input, Output, State

from app import app
from app import server


search_bar = dbc.Row(
    [
        dbc.Col(dbc.Input(type="search", placeholder="Search")),
        dbc.Col(
            dbc.Button(
                "Search", color="primary", className="ml-2", n_clicks=0
            ),
            width="auto",
        ),
    ],
    no_gutters=True,
    className="ml-auto flex-nowrap mt-3 mt-md-0",
    align="center",
)

navbar = dbc.Navbar(
    [
        html.A(
            # Use row and col to control vertical alignment of logo / brand
            dbc.Row(
                [
                    dbc.Col(dbc.NavbarBrand("Future of electricity in Germany: Prediction of the Prices on the basis of neural network", className="ml-2")),
                ],
                align="center",
                no_gutters=True,
            ),
            href="https://plotly.com",
        ),
        dbc.NavbarToggler(id="navbar-toggler", n_clicks=0),
        dbc.Collapse(
            search_bar, id="navbar-collapse", navbar=True, is_open=False
        ),
    ],
    color="dark",
    className= "navbar-style",
    dark=True,
)


submenu_1 = [
    html.Li(
        dbc.Row(
            [
                dbc.Col(dbc.NavLink("Home", href="/home", className="link-style")),
                dbc.Col(
                    html.I(className="fas fa-chevron-right mr-3",id="chevron-1"),
                    width="auto",

                ),
            ],
            className="my-1",
        ),
        style={"cursor": "pointer"},
        id="submenu-1",
    ),
    dbc.Collapse(
            [
                dbc.NavLink("Introduction", href="/home"),
                dbc.NavLink("Source of Data", href="/home"),
            ],
            id="submenu-1-collapse",
        ),
]

submenu_2 = [
    html.Li(
        # use Row and Col components to position the chevrons
        dbc.Row(
            [
                dbc.Col(dbc.NavLink("Historical data", href="/historical_data", className="link-style")),
                dbc.Col(html.I(className="fas fa-chevron-right mr-3",
                               id="chevron-2")
                        ,width="auto",
                ),
            ],
            className="my-1",
        ),
        style={"cursor": "pointer"},
        id="submenu-2",
    ),
    # we use the Collapse component to hide and reveal the navigation links
    dbc.Collapse(
        [
            dbc.NavLink("electricity prices", href="/historical_data"),
            dbc.NavLink("max temperature", href="/historical_data"),
            dbc.NavLink("Sun hours", href="/historical_data"),
        ],
        id="submenu-2-collapse",
    ),
]

submenu_3 = [
    html.Li(
        dbc.Row(
            [
                dbc.Col(dbc.NavLink("Prediction", href="/prediction", className="link-style")),
                dbc.Col(
                    html.Span(className="fas fa-chevron-right mr-3",
                           id="chevron-3",
                           ),
                    width="auto",
                ),
            ],
            className="my-1",
        ),
        style={"cursor": "pointer"},
        id="submenu-3",
    ),
    dbc.Collapse(
        [
            dbc.NavLink("Applied Algorithm", href="/prediction"),
            dbc.NavLink("Prediction Results", href="/prediction"),
        ],
        id="submenu-3-collapse",
    ),

]


sidebar = html.Div(
    [
        html.H3("Applied Machine Intelligence Project", className="display-12"),
        html.H3(
            "Group 4", className="lead"
        ),
        html.Hr(),
        dbc.Nav(submenu_1 + submenu_2 + submenu_3, vertical=True),
    ],
    className="sidebar-style",
    id="sidebar",
)

def toggle_collapse(n, is_open):
    if n:
        return not is_open
    return is_open
def set_navitem_class(is_open):
    if is_open:
        return "fas fa-chevron-down mr-3"
    return "fas fa-chevron-right mr-3"

for i in [1,2,3]:
    app.callback(
        Output(f"submenu-{i}-collapse", "is_open"),
        [Input(f"chevron-{i}", "n_clicks")],
        [State(f"submenu-{i}-collapse", "is_open")],
    )(toggle_collapse)

    app.callback(
        Output(f"chevron-{i}", "className"),
        [Input(f"submenu-{i}-collapse", "is_open")],
    )(set_navitem_class)
