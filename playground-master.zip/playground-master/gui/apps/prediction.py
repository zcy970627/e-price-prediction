import dash_core_components as dcc
import dash_bootstrap_components as dbc
import dash_html_components as html
import pathlib
from dash.dependencies import Input, Output, State

from app import app
from apps import side_and_nav_bars


# get relative data folder
PATH = pathlib.Path(__file__).parent
DATA_PATH = PATH.joinpath("../datasets").resolve()

prediction_content = html.Div(id="page-3-content",className="content_style",
    children=[
        html.Div("this is prediction",
                 id="div1"

            ),
        html.Div("this is prediction 2"

        ),
        ],
    )

layout = html.Div([side_and_nav_bars.navbar,side_and_nav_bars.sidebar,prediction_content])

@app.callback(Output('page-3-content', 'children'),
              [Input('div1', 'value')])
def display_value(value):
    return 'You have selected "{}"'.format(value)